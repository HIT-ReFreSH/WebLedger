<template>
  <div style="font-size: 16px; padding: 20px 0; text-align: center; line-height: 30px; color: #666">
    <div> </div>
    <div> </div>
  </div>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style scoped>

</style>