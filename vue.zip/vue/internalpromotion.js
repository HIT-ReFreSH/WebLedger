import request from '@/utils/request'

// 查询内推管理列表
export function listInternalpromotion(query) {
  return request({
    url: '/internalpromotion/internalpromotion/list',
    method: 'get',
    params: query
  })
}

// 查询内推管理详细
export function getInternalpromotion(id) {
  return request({
    url: '/internalpromotion/internalpromotion/' + id,
    method: 'get'
  })
}

// 新增内推管理
export function addInternalpromotion(data) {
  return request({
    url: '/internalpromotion/internalpromotion',
    method: 'post',
    data: data
  })
}

// 修改内推管理
export function updateInternalpromotion(data) {
  return request({
    url: '/internalpromotion/internalpromotion',
    method: 'put',
    data: data
  })
}

// 删除内推管理
export function delInternalpromotion(id) {
  return request({
    url: '/internalpromotion/internalpromotion/' + id,
    method: 'delete'
  })
}
